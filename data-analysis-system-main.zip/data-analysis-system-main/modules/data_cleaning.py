"""
数据清洗模块
负责：缺失值处理、异常值检测、数据标准化
==============================================
【供其他模块调用接口】
    from modules.data_cleaning import DataCleaner
    cleaner = DataCleaner(df)
    result = cleaner.fill_missing(method='mean')
    result = cleaner.remove_outliers()
"""
import pandas as pd
import numpy as np


class DataCleaner:
    """数据清洗器 —— 提供多种数据清洗功能"""
    
    def __init__(self, df):
        """
        初始化数据清洗器
        参数:
            df: pandas DataFrame
        """
        self.df = df.copy()
        self.cleaning_history = []
    
    def get_missing_info(self):
        """
        获取缺失值信息
        返回:
            dict: 各列缺失值统计
        """
        missing_info = {}
        for col in self.df.columns:
            missing_count = self.df[col].isnull().sum()
            if missing_count > 0:
                missing_info[col] = {
                    'count': missing_count,
                    'percent': round(missing_count / len(self.df) * 100, 2)
                }
        return missing_info
    
    def get_outlier_info(self, method='iqr'):
        """
        获取异常值信息
        参数:
            method: 检测方法 ('iqr' 或 'zscore')
        返回:
            dict: 各列异常值统计
        """
        outlier_info = {}
        numeric_cols = self.df.select_dtypes(include=['number']).columns.tolist()
        
        for col in numeric_cols:
            data = self.df[col].dropna()
            if len(data) < 3:
                continue
            
            if method == 'iqr':
                # IQR方法
                q1 = data.quantile(0.25)
                q3 = data.quantile(0.75)
                iqr = q3 - q1
                lower_bound = q1 - 1.5 * iqr
                upper_bound = q3 + 1.5 * iqr
                outliers = data[(data < lower_bound) | (data > upper_bound)]
            else:
                # Z-score方法
                z_scores = np.abs((data - data.mean()) / data.std())
                outliers = data[z_scores > 3]
            
            if len(outliers) > 0:
                outlier_info[col] = {
                    'count': len(outliers),
                    'percent': round(len(outliers) / len(data) * 100, 2),
                    'min': float(outliers.min()),
                    'max': float(outliers.max())
                }
        
        return outlier_info
    
    def fill_missing(self, method='mean', columns=None):
        """
        填充缺失值
        参数:
            method: 填充方法 ('mean', 'median', 'mode', 'ffill', 'bfill', 'constant')
            columns: 指定填充的列（None表示所有列）
        
        返回:
            dict: {'success': True/False, 'message': str, 'df': DataFrame}
        """
        try:
            target_cols = columns if columns else self.df.columns
            df_copy = self.df.copy()
            
            for col in target_cols:
                if col not in df_copy.columns:
                    continue
                
                missing_count = df_copy[col].isnull().sum()
                if missing_count == 0:
                    continue
                
                dtype = df_copy[col].dtype
                
                if method == 'mean':
                    if np.issubdtype(dtype, np.number):
                        fill_val = df_copy[col].mean()
                    else:
                        fill_val = df_copy[col].mode()[0]
                
                elif method == 'median':
                    if np.issubdtype(dtype, np.number):
                        fill_val = df_copy[col].median()
                    else:
                        fill_val = df_copy[col].mode()[0]
                
                elif method == 'mode':
                    fill_val = df_copy[col].mode()[0] if not df_copy[col].mode().empty else ''
                
                elif method == 'ffill':
                    df_copy[col] = df_copy[col].fillna(method='ffill')
                    continue
                
                elif method == 'bfill':
                    df_copy[col] = df_copy[col].fillna(method='bfill')
                    continue
                
                elif method == 'constant':
                    if np.issubdtype(dtype, np.number):
                        fill_val = 0
                    else:
                        fill_val = 'N/A'
                
                else:
                    return {'success': False, 'message': f'不支持的填充方法: {method}'}
                
                df_copy[col] = df_copy[col].fillna(fill_val)
                self.cleaning_history.append(f"填充列 [{col}] 的 {missing_count} 个缺失值，使用方法: {method}")
            
            self.df = df_copy
            return {
                'success': True,
                'message': f'缺失值填充完成，共处理 {len(target_cols)} 列',
                'df': self.df
            }
        
        except Exception as e:
            return {'success': False, 'message': f'填充失败: {str(e)}'}
    
    def remove_missing(self, threshold=0.5):
        """
        删除缺失值过多的行或列
        参数:
            threshold: 缺失值比例阈值，超过此值则删除
        
        返回:
            dict: {'success': True/False, 'message': str, 'df': DataFrame}
        """
        try:
            initial_rows = len(self.df)
            initial_cols = len(self.df.columns)
            
            # 删除缺失值比例超过阈值的行
            row_missing_ratio = self.df.isnull().sum(axis=1) / len(self.df.columns)
            rows_to_drop = row_missing_ratio[row_missing_ratio > threshold].index
            self.df = self.df.drop(rows_to_drop)
            
            # 删除缺失值比例超过阈值的列
            col_missing_ratio = self.df.isnull().sum(axis=0) / len(self.df)
            cols_to_drop = col_missing_ratio[col_missing_ratio > threshold].index
            self.df = self.df.drop(cols_to_drop, axis=1)
            
            removed_rows = initial_rows - len(self.df)
            removed_cols = initial_cols - len(self.df.columns)
            
            self.cleaning_history.append(f"删除 {removed_rows} 行缺失值过多的数据")
            if removed_cols > 0:
                self.cleaning_history.append(f"删除 {removed_cols} 列缺失值过多的数据")
            
            return {
                'success': True,
                'message': f'删除完成：移除 {removed_rows} 行，{removed_cols} 列',
                'df': self.df
            }
        
        except Exception as e:
            return {'success': False, 'message': f'删除失败: {str(e)}'}
    
    def remove_outliers(self, method='iqr', columns=None):
        """
        删除异常值
        参数:
            method: 检测方法 ('iqr' 或 'zscore')
            columns: 指定处理的列（None表示所有数值列）
        
        返回:
            dict: {'success': True/False, 'message': str, 'df': DataFrame}
        """
        try:
            numeric_cols = self.df.select_dtypes(include=['number']).columns.tolist()
            target_cols = columns if columns else numeric_cols
            target_cols = [c for c in target_cols if c in numeric_cols]
            
            initial_rows = len(self.df)
            
            for col in target_cols:
                data = self.df[col]
                
                if method == 'iqr':
                    q1 = data.quantile(0.25)
                    q3 = data.quantile(0.75)
                    iqr = q3 - q1
                    lower_bound = q1 - 1.5 * iqr
                    upper_bound = q3 + 1.5 * iqr
                    mask = (data >= lower_bound) & (data <= upper_bound)
                else:
                    z_scores = np.abs((data - data.mean()) / data.std())
                    mask = z_scores <= 3
                
                self.df = self.df[mask | data.isnull()]
            
            removed_rows = initial_rows - len(self.df)
            self.cleaning_history.append(f"删除 {removed_rows} 行异常值数据（方法: {method}）")
            
            return {
                'success': True,
                'message': f'异常值处理完成，移除 {removed_rows} 行',
                'df': self.df
            }
        
        except Exception as e:
            return {'success': False, 'message': f'处理失败: {str(e)}'}
    
    def remove_duplicates(self):
        """
        删除重复行
        
        返回:
            dict: {'success': True/False, 'message': str, 'df': DataFrame}
        """
        try:
            initial_rows = len(self.df)
            self.df = self.df.drop_duplicates()
            removed_rows = initial_rows - len(self.df)
            
            if removed_rows > 0:
                self.cleaning_history.append(f"删除 {removed_rows} 行重复数据")
            
            return {
                'success': True,
                'message': f'重复行处理完成，移除 {removed_rows} 行',
                'df': self.df
            }
        
        except Exception as e:
            return {'success': False, 'message': f'处理失败: {str(e)}'}
    
    def standardize(self, columns=None):
        """
        数据标准化（Z-score标准化）
        
        返回:
            dict: {'success': True/False, 'message': str, 'df': DataFrame}
        """
        try:
            numeric_cols = self.df.select_dtypes(include=['number']).columns.tolist()
            target_cols = columns if columns else numeric_cols
            target_cols = [c for c in target_cols if c in numeric_cols]
            
            for col in target_cols:
                mean = self.df[col].mean()
                std = self.df[col].std()
                if std > 0:
                    self.df[col] = (self.df[col] - mean) / std
            
            self.cleaning_history.append(f"标准化 {len(target_cols)} 列数据")
            
            return {
                'success': True,
                'message': f'标准化完成，处理 {len(target_cols)} 列',
                'df': self.df
            }
        
        except Exception as e:
            return {'success': False, 'message': f'标准化失败: {str(e)}'}
    
    def get_cleaning_history(self):
        """获取清洗历史记录"""
        return self.cleaning_history
    
    def get_result(self):
        """获取清洗后的DataFrame"""
        return self.df


# ==================== 便捷函数接口 ====================

def clean_missing(df, method='mean', threshold=0.5, action='fill'):
    """
    便捷函数：处理缺失值
    参数:
        df: DataFrame
        method: 填充方法
        threshold: 删除阈值
        action: 'fill' 或 'remove'
    
    返回:
        (清洗后的DataFrame, 清洗信息)
    """
    cleaner = DataCleaner(df)
    
    if action == 'fill':
        result = cleaner.fill_missing(method=method)
    else:
        result = cleaner.remove_missing(threshold=threshold)
    
    return result['df'], result


def detect_outliers(df, method='iqr'):
    """
    便捷函数：检测异常值
    """
    cleaner = DataCleaner(df)
    return cleaner.get_outlier_info(method=method)


def remove_outliers(df, method='iqr'):
    """
    便捷函数：删除异常值
    """
    cleaner = DataCleaner(df)
    result = cleaner.remove_outliers(method=method)
    return result['df'], result